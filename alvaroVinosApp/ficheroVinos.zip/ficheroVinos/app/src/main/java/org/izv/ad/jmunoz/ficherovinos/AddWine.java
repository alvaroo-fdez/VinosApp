package org.izv.ad.jmunoz.ficherovinos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class AddWine extends AppCompatActivity {

    private static final String TAG = "xyzyx";
    private Button btAdd;
    private Intent i;
    private Files files;

    private EditText etId, etName, etCellar, etColour, etOrigin, etDegrees, etDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vine);

        init();

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               /* if(validateWine(view)) {

                }
                        if (files.writeFile(getFilesDir(), Files.writeWine(createWine()))) {
                            Snackbar.make(view, "Write success ...", Snackbar.LENGTH_SHORT).show();
                        } else {
                            Snackbar.make(view, "Write wrong ...", Snackbar.LENGTH_SHORT).show();
                        }
                        startActivity(i);*/



            }});

    }

    public void init(){

        btAdd = findViewById(R.id.btAddWine);
        files = new Files();
        i = new Intent(AddWine.this, MainActivity.class);

        etId = findViewById(R.id.etIdAdd);
        etId.setText("");
        etName = findViewById(R.id.etNameAdd);
        etName.setText("");
        etCellar = findViewById(R.id.etCellarAdd);
        etCellar.setText("");
        etColour = findViewById(R.id.etColourAdd);
        etColour.setText("");
        etOrigin = findViewById(R.id.etOriginAdd);
        etOrigin.setText("");
        etDegrees = findViewById(R.id.etDegreesAdd);
        etDegrees.setText("");
        etDate = findViewById(R.id.etYearAdd);
        etDate.setText("");
    }

    public boolean emptyField(){
        if(
                etId.getText().length() == 0 || etName.getText().length() == 0 ||
                etCellar.getText().length() == 0 ||  etColour.getText().length() == 0 ||
                etOrigin.getText().length() == 0 || etDegrees.getText().length() == 0 ||
                etDate.getText().length() == 0
        ){
           return true;
        }
        else{
            return false;
        }
    }

    public Wine createWine(){

        Long id = null; Double degrees = 0.0; int date = 0;
        try {
            id = Long.parseLong(etId.getText().toString());
            degrees = Double.parseDouble(etDegrees.getText().toString());
            date = Integer.parseInt(etDate.getText().toString());
        }catch(NumberFormatException e){
            e.printStackTrace();
        }
        String name = etName.getText().toString();
        String cellar = etCellar.getText().toString();
        String colour = etColour.getText().toString();
        String origin = etOrigin.getText().toString();

        Wine w = new Wine(id,name,cellar,colour,origin,degrees,date);

        return w;
    }

    public boolean existId(){
        List<Wine> w = files.readFile(getFilesDir());
        Log.v(TAG, w.toString());
        return true;
    }

    public boolean validateWine(View view){
        if(existId()){
            Snackbar.make(view, "This Id already exist ...", Snackbar.LENGTH_SHORT).show();
            return false;
        }
        else {
            if(emptyField()) {
               Snackbar.make(view,"Any field is empty ...",Snackbar.LENGTH_SHORT).show();
               return false;
            }
            else {
                return true;
            }
        }

    }

}