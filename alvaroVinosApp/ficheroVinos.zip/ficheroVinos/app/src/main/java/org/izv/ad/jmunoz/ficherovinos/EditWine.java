package org.izv.ad.jmunoz.ficherovinos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class EditWine extends AppCompatActivity {

    private Button btEdit, btDelete;
    private TextView tvSeeId;
    private EditText etNameEdit, etCellarEdit, etColourEdit, etOriginEdit, etDegreesEdit, etDateEdit;
    private Files files;
    private Bundle b;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vine);

        init();

        id = Integer.parseInt(b.getString("valor"));

        tvSeeId.setText(String.valueOf(id));
        loadWineInfo();



        btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveList(saveWine());
                Intent i = new Intent(EditWine.this, MainActivity.class);
                startActivity(i);
            }});

        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveList(deleteWine());
                Intent i = new Intent(EditWine.this, MainActivity.class);
                startActivity(i);
            }});

    }

    public void init(){

        btEdit = findViewById(R.id.btEditVine);
        btDelete = findViewById(R.id.btDelete);
        tvSeeId = findViewById(R.id.tvSeeId);
        etCellarEdit = findViewById(R.id.etCellarEdit);

        b = getIntent().getExtras();

        etNameEdit = findViewById(R.id.etNameEdit);
        etCellarEdit = findViewById(R.id.etCellarEdit);
        etColourEdit = findViewById(R.id.etColourEdit);
        etOriginEdit = findViewById(R.id.etOriginEdit);
        etDegreesEdit = findViewById(R.id.etDegreesEdit);
        etDateEdit = findViewById(R.id.etYearEdit);

        files = new Files();

    }

    public void loadWineInfo(){
        List<Wine> w = files.readFile(getFilesDir());
        etNameEdit.setText(w.get(id).getName());
        etCellarEdit.setText(w.get(id).getCellar());
        etColourEdit.setText(w.get(id).getColour());
        etOriginEdit.setText(w.get(id).getOrigin());
        etDegreesEdit.setText(String.valueOf(w.get(id).getDegrees()));
        etDateEdit.setText(String.valueOf(w.get(id).getDate()));
    }

    public List<Wine> saveWine(){
        List<Wine> w = files.readFile(getFilesDir());
        w.get(id).setName(etNameEdit.getText().toString());
        w.get(id).setCellar(etCellarEdit.getText().toString());
        w.get(id).setColour(etColourEdit.getText().toString());
        w.get(id).setOrigin(etOriginEdit.getText().toString());
        try {
            w.get(id).setDegrees(Double.parseDouble(etDegreesEdit.getText().toString()));
            w.get(id).setDate(Integer.parseInt(etDateEdit.getText().toString()));
        }catch(NumberFormatException e){
            e.printStackTrace();
        }
        return w;
    }

    public void saveList(List<Wine> w){
        files.deleteFile(getFilesDir());

        for(int i= 0;i < w.size();i++){
            files.writeFile(getFilesDir(), Files.writeWine(w.get(i)));
        }
    }

    public List<Wine> deleteWine(){
        List<Wine> w = files.readFile(getFilesDir());
        w.remove(id);
        return w;
    }

}