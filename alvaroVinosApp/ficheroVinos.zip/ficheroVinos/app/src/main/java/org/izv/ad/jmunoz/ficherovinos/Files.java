package org.izv.ad.jmunoz.ficherovinos;

import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Files extends AppCompatActivity{

    public static final String fileName = "archivo.txt";

    public boolean writeFile(File file, String string) {

            File f = new File(file, fileName);
            FileWriter fw = null;
            boolean ok = true;
            try {
                fw = new FileWriter(f, true);
                fw.write(string);
                fw.write("\n");
                fw.flush();
                fw.close();
            } catch (IOException e) {
                ok = false;
            }
            return ok;
        }

    public void writeInternalFile(EditText et) {
        String text = et.getText().toString();
        writeFile(getFilesDir(), text);
    }

    public void writeExternalFile(EditText et) {
        String text = et.getText().toString();
        writeFile(getExternalFilesDir(null), text);
    }

    public List<Wine> readFile(File dir) {

        File f = new File(dir, fileName);
        BufferedReader br;
        String texto = "";
        List<Wine> wineList = null;
        String linea = "";

        try {
            br = new BufferedReader(new FileReader(f));
            linea = br.readLine();
            wineList = new LinkedList<>();
            while (linea != null){
                wineList.add(readWine(linea));
                linea = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            texto = "";
        }
        return wineList;
    }

    public List<Wine> readInternalFile() {
        return readFile(getFilesDir());
    }

    public List<Wine> readExternalFile() {
        return readFile(getExternalFilesDir(null));
    }

    public static Wine readWine(String s) {
        String[] atributos = s.split(";");

        Wine w = null;
        if (atributos.length >= 6) {
            w = new Wine();
            try {
                w.setId(Long.parseLong(atributos[0].trim()));
            }catch(NumberFormatException e){
                e.printStackTrace();
            }
            w.setName(atributos[1].trim());
            w.setCellar(atributos[2].trim());
            w.setColour(atributos[3].trim());
            w.setOrigin(atributos[4].trim());
            try {
                w.setDegrees(Double.parseDouble(atributos[5].trim()));
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace();
            }
            try {
                w.setDate(Integer.parseInt(atributos[6].trim()));
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace();
            }
        }
        return w;
    }

    public static String writeWine(Wine w){ // guardar vino en fichero

        return w.getId() + "; " +
                w.getName() + "; " +
                w.getCellar() + "; " +
                w.getColour() + "; " +
                w.getOrigin() + "; " +
                w.getDegrees() + "; " +
                w.getDate();

    }

    public void deleteFile(File file) {
        File f = new File(file,fileName);
        f.delete();
    }
}
