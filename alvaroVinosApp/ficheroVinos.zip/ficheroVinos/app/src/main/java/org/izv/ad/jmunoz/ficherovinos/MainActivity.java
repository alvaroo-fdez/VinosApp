package org.izv.ad.jmunoz.ficherovinos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btEdit, btAdd;
    private EditText etId;
    private TextView tvText;
    private Files files;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        if(files.readFile(getFilesDir()) != null) {
            tvText.setText(seeList(files.readFile(getFilesDir())));
        }
        else{
            tvText.setText("Empty file Wine");
        }

        btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etId.length() > 0) {
                    if(existWine(files.readFile(getFilesDir()))) {
                        openActivity();
                    }
                    else{
                        Snackbar.make(view,"ID NOT EXIST ...", Snackbar.LENGTH_SHORT).show();
                    }
                }
            }});

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddWine.class);
                startActivity(i);
            }});

    }

    public void init(){

        files = new Files();
        tvText = findViewById(R.id.tvText);
        btEdit = findViewById(R.id.btEdit);
        btAdd = findViewById(R.id.btAdd);
        etId = findViewById(R.id.etId);

    }

    public void openActivity(){
        Intent i = new Intent(this, EditWine.class);

        Bundle b = new Bundle();
        b.putString("valor", etId.getText().toString());
        i.putExtras(b);
        startActivity(i);
    }

    public String seeList(List<Wine> w) {
        String text = "";
        for(int i = 0;i < w.size();i++) {
            text += "\nWINE " + w.get(i).getName() + " ID " + w.get(i).getId() + '\n' +
                    "CELLAR " + w.get(i).getCellar() + " ORIGIN " + w.get(i).getOrigin() + '\n' +
                    "COLOUR " + w.get(i).getColour() + " DEGREES " + w.get(i).getDegrees() + " DATE " + w.get(i).getDate() + '\n';
        }
        return text;
    }

    public  boolean existWine(List<Wine> w){
        for(int i=0;i <w.size();i++){
            if(w.get(i).getId() == Long.parseLong(etId.getText().toString())){
                return true;
            }
        }
        return false;
    }

}